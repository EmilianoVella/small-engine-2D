#include <string.h>
#include <math.h>
#include <stdio.h>

typedef struct vector2
{
    float x,y;

}Vector2_t;

typedef struct vector3
{
    float x;
    float y;
    float z;

}Vector3_t;

Vector2_t Vector2_new(float x, float y);
Vector3_t Vector3_new(float x, float y, float z);
Vector3_t Vector3_zero();
float inversed_slope(float x0, float y0, float x1, float y1);
float Lerp(float start, float end, float gradient);

typedef struct Context
{
    int width;
    int height;
    unsigned char* frameBuffer;
} context_t;

typedef struct Vertex
{
    Vector3_t position;
    Vector3_t normal;
    Vector3_t color;

    int raster_x;
    int raster_y;
} vertex_t;

typedef struct Triangle
{
    vertex_t a;
    vertex_t b;
    vertex_t c;

} triangle_t;

vertex_t vertex_new(Vector3_t position);
triangle_t Triangle_new(vertex_t a, vertex_t b, vertex_t c);
Vector2_t point_to_screen(float point_x, float point_y, int screen_width, int screen_height);
void rasterizer(context_t *ctx, triangle_t *triangle);
void clear_screen(context_t *context);
void put_pixel(Vector2_t *vertex_pos, context_t *context);
//void put_pixel(Vector2_t *vertex_pos, context_t *context, unsigned char R, unsigned char G, unsigned char B);
float gradient(float i, float P0, float P1);
float get_magnitude(Vector2_t point_a, Vector2_t point_b);
float dot_product(Vector2_t a, Vector2_t b);
