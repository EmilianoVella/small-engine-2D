#include <stdio.h>


struct vector2
{
    float x,y;

}vector2_t;

struct vector3
{
    float x;
    float y;
    float z;

}vector3_t;

vector2_t Vector2_new(float x, float y);
vector3_t Vector3_new(float x, float y, float z);
vector3_t Vector3_zero();
float inversed_slope(float x0, float y0, float x1, float y1);
float Lerp(float start, float end, float gradient);