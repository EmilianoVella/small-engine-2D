#include "aiv_rasterizer.h"

Vector2_t Vector2_new(float x, float y)
{
    Vector2_t new_vector2;

    new_vector2.x = x;
    new_vector2.y = y;

    return new_vector2;
}
Vector3_t Vector3_new(float x, float y, float z)
{
    Vector3_t newVector3; // = {.x = x, .y = y, .z = z};

    newVector3.x = x;
    newVector3.y = y;
    newVector3.z = z;

    return newVector3;
}
Vector3_t Vector3_zero()
{
    Vector3_t new_vector3; // = {0, 0, 0};

    new_vector3.x = 0;
    new_vector3.y = 0;
    new_vector3.z = 0;

    return new_vector3;
}
float Lerp(float start, float end, float gradient)
{
    return start + (end - start) * gradient;
}
float inversed_slope(float x0, float y0, float x1, float y1)
{
    return (x1 - x0) / (y1 - y0);
}
float gradient(float i, float P0, float P1)
{
    float to_return;
    if (P0 != P1)
        return to_return = (i - P0) / (P1 - P0);

    return P0 || P1;
}

Vector2_t point_to_screen(float point_x, float point_y, int screen_width, int screen_height)
{
    Vector2_t screen_point;
    screen_point.x = ((point_x + 1) * screen_width) / 2;
    screen_point.y = screen_height - (((point_y + 1) * screen_height) / 2);
    return screen_point;
}

vertex_t vertex_new(Vector3_t position)
{
    vertex_t vertex;
    memset(&vertex, 0, sizeof(vertex_t));
    vertex.position = position;
    return vertex;
}
triangle_t Triangle_new(vertex_t a, vertex_t b, vertex_t c)
{
    triangle_t triangle = {.a = a,
                           .b = b,
                           .c = c};

    return triangle;
}
// float DotProduct(Vector2_t a, Vector3_t b)
// {
//     float dtProduct = a.x * b.x + a.y * b.y;
//     return dtProduct;
// }
float dot_product(Vector2_t a, Vector2_t b)
{
    return a.x * b.x + a.y * b.y;
}
float get_magnitude(Vector2_t point_a, Vector2_t point_b)
{
    return sqrt(pow(point_b.x - point_a.x, 2) + pow(point_b.y - point_a.y, 2));
}
void rasterizer(context_t *context, triangle_t *triangle)
{
    Vector2_t vertex_a = point_to_screen(triangle->a.position.x, triangle->a.position.y, context->width, context->height);
    Vector2_t vertex_b = point_to_screen(triangle->b.position.x, triangle->b.position.y, context->width, context->height);
    Vector2_t vertex_c = point_to_screen(triangle->c.position.x, triangle->c.position.y, context->width, context->height);

    put_pixel(&vertex_a, context);
    put_pixel(&vertex_b, context);
    put_pixel(&vertex_c, context);

    Vector2_t P[3] = {vertex_a, vertex_b, vertex_c};

    Vector2_t temp;

    if (P[1].y < P[0].y)
    {
        temp = P[0];
        P[0] = P[1];
        P[1] = temp;
    }

    if (P[2].y < P[1].y)
    {
        temp = P[2];
        P[2] = P[1];
        P[1] = temp;
    }

    if (P[1].y < P[0].y)
    {
        temp = P[0];
        P[0] = P[1];
        P[1] = temp;
    }

    // float distance_a = (P[1].x - P[0].x);
    // float distance_b = (P[2].x - P[0].x);
    // float ipotenusa = sqrt(pow(distance_a, 2) + pow(distance_b, 2));
    // float ipotenusa_y = sqrt(pow(P[0].y, 2) + pow(P[1].y, 2));

    Vector2_t p_3;
    float p2_magnitude = get_magnitude(P[0], P[2]);
    Vector2_t for_dot = {.x = P[2].x - P[0].x, .y = P[2].y - P[0].y};
    float dot = dot_product(P[1], for_dot);

    p_3.x = (dot / pow(p2_magnitude, 2)) * P[2].x;
    p_3.y = (dot / pow(p2_magnitude, 2)) * P[2].y;

    //printf("%f\n", ipotenusa);
    for (float i = P[0].y; i < P[1].y; i++)
    {
        //calculate gradient and find X
        float gradient_pixel_p0_p1 = gradient(i, P[1].y, P[0].y);
        float lerp_value_p0_p1 = Lerp(P[1].x, P[0].x, gradient_pixel_p0_p1);

        Vector2_t pixel;
        pixel.y = i;
        pixel.x = lerp_value_p0_p1;
        put_pixel(&pixel, context);
    }

    for (int i = P[1].y; i < P[2].y; i++)
    {
        float gradient_pixel_p1_p2 = gradient(i, P[2].y, P[1].y);
        float lerp_value_p1_p2 = Lerp(P[2].x, P[1].x, gradient_pixel_p1_p2);

        Vector2_t pixel;
        pixel.y = i;
        pixel.x = lerp_value_p1_p2;
        put_pixel(&pixel, context);

    }
    for (int i = P[0].y; i < P[2].y; i++)
    {
        float gradient_pixel_p0_p2 = gradient(i, P[2].y, P[0].y);
        float lerp_value_p0_p2 = Lerp(P[2].x, P[0].x, gradient_pixel_p0_p2);

        Vector2_t pixel;
        pixel.y = i;
        pixel.x = lerp_value_p0_p2;
        put_pixel(&pixel, context);
    }
}
void put_pixel(Vector2_t *vertex_pos, context_t *context)
{
   // vector2_t vertex_pos = point_to_screen(vertex_pos->x,vertex_pos->y,context.width, context.height);

    if (vertex_pos->x < 0 || vertex_pos->x > context->width - 1)
        return;
    if (vertex_pos->y < 0 || vertex_pos->y > context->height - 1)
        return;

    int index = (vertex_pos->y * context->width * 4) + (vertex_pos->x * 4);
    int backR = context->frameBuffer[index];
    int backG = context->frameBuffer[index + 1];
    int backB = context->frameBuffer[index + 2];
    context->frameBuffer[index] = 1 + backR;
    context->frameBuffer[index + 1] = 1 + backG;
    context->frameBuffer[index + 2] = 1 + backB;
}
void clear_screen(context_t *context)
{
    memset((void *)context->frameBuffer, 0, sizeof(context->frameBuffer));
}
